This folder contains the flash file and configuration file used to create the charts. 
If the user want to change other flash files, please go to http://www.amcharts.com/  find more.

License:
"You can download and use all amCharts products for free. 
The only limitation of the free version is that a small link to this web site will be displayed in the top left corner of your charts. 
If you would like to use charts without this link, or you appreciate the software and would like to support its creators, please purchase a commercial license."
